
SELECT *
FROM course;